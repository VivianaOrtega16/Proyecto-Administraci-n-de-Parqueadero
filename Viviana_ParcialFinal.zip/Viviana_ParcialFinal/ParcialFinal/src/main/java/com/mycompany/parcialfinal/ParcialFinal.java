/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.parcialfinal;

/**
 *
 * @author vivid
 */
public class ParcialFinal {

    public static void main(String[] args) {
     
    }
}
