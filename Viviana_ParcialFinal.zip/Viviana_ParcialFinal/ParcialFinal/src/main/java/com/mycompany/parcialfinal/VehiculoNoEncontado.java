
package com.mycompany.parcialfinal;

import java.util.ArrayList;

/**
 *
 * @author vivid
 */
public class VehiculoNoEncontado extends Exception{

    public VehiculoNoEncontado(String message) {
        super(message);
    }
    //aqui debe estar la exepcion
    //no tiene atributos
    //tiene constructores del super
    //creamos un metiodos para retirar el vehiculo del parquedero
  
    
    
}
